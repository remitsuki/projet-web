<?php
session_start();
if (isset($_SESSION['admin']))
    header('location:Administration/index.php');
if (isset($_SESSION['user']))
    header('location:Shop/');
include 'Shop/config/sessionN.php';
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Shop - Sauce Site</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }
    </style>

</head>

<body onload="AffichageProduits()">
    <header>
        <div class="collapse bg-dark" id="navbarHeader">
            <div class="container">
                <div class="row">
                    <div class="col-sm-8 col-md-7 py-4">
                        <h4 class="text-white">A propos de nos merveilleuses sauces</h4>
                        <p class="text-muted">Une sauce est une préparation culinaire, froide, tiède ou chaude, destinée à être servie avec un mets salé ou sucré. Composée d'un simple jus ou d'un apprêt très élaboré, la sauce peut servir d'accompagnement, comme la mayonnaise, la béarnaise ou le coulis de fruits, mais aussi d'élément de cuisson, comme pour une daube ou un ragoût. D'une grande diversité, les sauces sont d'une consistance plus ou moins liquide que l'on peut détendre ou épaissir ; elles sont faites à partir de mélange à froid comme la vinaigrette, tiède comme l'émulsion au beurre d'une béarnaise, ou à chaud comme les déglaçages au vin, ou toutes sortes de fonds. Chacune d'elles peut être déclinée et agrémentée d'herbes, aromates, épices, colorants, alcools, mais aussi tomates, jus de fruits, de fromage ou autre foie gras.</p>
                    </div>
                    <div class="col-sm-4 offset-md-1 py-4">


                        <?php if (empty($_SESSION['user'])) : ?>
                            <form action='Shop/verifyP.php' method='POST'>
                                <h1 class='h3 mb-3 fw-normal text-white'>Connectez vous !</h1>

                                <div class='form-floating'>
                                    <input type='email' class='form-control' id='floatingInput' name='email' placeholder='name@example.com'>
                                    <label for='floatingInput'>Adresse mail</label>
                                </div>
                                <div class='form-floating'>
                                    <input type='password' class='form-control' id='floatingPassword' name='password' placeholder='Password'>
                                    <label for='floatingPassword'>Mot de passe</label>
                                </div>
                                <button class='w-100 btn btn-lg btn-primary' name='login' type='submit'>Sign in</button>
                                <?php
                                if (isset($_SESSION['error'])) {
                                    echo '
                                        <div class="text-danger ps-3">
                                            Identifiant ou mot de passe incorrect.
                                        </div>';
                                    unset($_SESSION['error']);
                                }
                                ?>
                                <div class='form-floating text-white'>
                                    <h6 class='mx-auto'>
                                        Pas encore <a href='../Inscription/index.php'>inscrit</a> ?
                                    </h6>
                                </div>
                            </form>
                        <?php else : ?>
                            <h4>
                                Bienvenue
                            </h4>
                            <a href='config/deconnexion.php'>
                                <button class='w-100 btn btn-lg btn-primary'>
                                    Se déconnecter
                                </button>
                            </a>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
        <div class='navbar navbar-dark bg-dark shadow-sm'>
            <div class='container'>
                <a href='#' class='navbar-brand d-flex align-items-center'>
                    <img src='IconeSauce.png' width='20' height='20' fill='none' stroke='currentColor' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' aria-hidden='true' class='me-2' viewBox='0 0 24 24'>
                    <path d='M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z' />
                    <circle cx='12' cy='13' r='4' /></img>
                    <strong>Sauce Site</strong>
                </a>
                <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbarHeader' aria-controls='navbarHeader' aria-expanded='false' aria-label='Toggle navigation'>
                    <span class='navbar-toggler-icon'></span>
                </button>

            </div>
        </div>
    </header>

    <main>
        <div>
            <div id="carouselExampleIndicators" class="carousel slide pointer-event" data-bs-ride="carousel">
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2" class=""></button>
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3" class="active" aria-current="true"></button>
                </div>
                <div class="carousel-inner" id="carouselproduit">
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
        <div class="text-center ">
            <h1 class="font-weight-bold">
                Nos derniers arrivages.
            </h1>
        </div>
    </main>

    <footer class="text-muted py-5">
        <div class="container">
            <iframe src="https://open.spotify.com/embed/track/2ChNJTAMVSDEc8hsdiF1Vs" width="100%" height="80" frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe>
            <p class="float-end mb-1">
                <a href="#" class="text-decoration-none">Retour en haut
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-double-up" viewBox="0 0 16 16">
                        <path fill-rule="evenodd" d="M7.646 2.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1-.708.708L8 3.707 2.354 9.354a.5.5 0 1 1-.708-.708l6-6z"></path>
                        <path fill-rule="evenodd" d="M7.646 6.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1-.708.708L8 7.707l-5.646 5.647a.5.5 0 0 1-.708-.708l6-6z"></path>
                    </svg>
                </a>
            </p>
            <p class="mb-0">Suivez-nous sur <a href="https://www.instagram.com/rawsauce_._/" target="_blank" class="text-decoration-none">Instagram
                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/96/Instagram.svg/1200px-Instagram.svg.png" width="17"></a></p>

        </div>
    </footer>
    <script>
        function AffichageProduits() {
            $.ajax({
                type: "GET",
                url: 'config/affichage.php',
                dataType: 'json',
                data: {},
                success: function(obj) {
                    document.getElementById("carouselproduit").innerHTML = obj.result;
                },
            });
        }
    </script>
</body>

</html>