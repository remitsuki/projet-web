<?php

require 'accesbdd.php';

$req = $access->prepare("SELECT * FROM sauce ORDER BY id DESC LIMIT 3");

$req->execute();

$data = $req->fetchAll(PDO::FETCH_OBJ);

$obj['result'] = "";

$imgcasse = "'https://upload.wikimedia.org/wikipedia/commons/thumb/1/16/No_image_available_450_x_600.svg/450px-No_image_available_450_x_600.svg.png'";
$nbproduit = 0;
foreach ($data as $sauce) {
    if ($nbproduit == 0)
        $obj['result'] = $obj['result'] .
            '<div class="carousel-item carousel-item-next carousel-item-start" data-bs-interval="10000">
                <svg class="bd-placeholder-img bd-placeholder-img-lg d-block w-100" width="800" height="400" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: First slide" preserveAspectRatio="xMidYMid slice" focusable="false">
                    <rect width="100%" height="100%" fill="#777">
                    </rect>
                    <text x="50%" y="50%" fill="#555" dy=".3em">' . $sauce->nom . '</text>
                </svg>
                <div class="carousel-caption d-none d-md-block">
                    <p>'. $sauce->textedescription .'</p>
                    <p><a class="btn btn-lg btn-primary" href="Shop/">Achetez maintenant !</a></p>
                </div>
            </div>';
    if ($nbproduit == 1)
        $obj['result'] = $obj['result'] .
            '<div class="carousel-item">
                <svg class="bd-placeholder-img bd-placeholder-img-lg d-block w-100" width="800" height="400" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Second slide" preserveAspectRatio="xMidYMid slice" focusable="false">
                    <rect width="100%" height="100%" fill="#777">
                    </rect>
                    <text x="50%" y="50%" fill="#555" dy=".3em">' . $sauce->nom . '</text>
                </svg>
                <div class="carousel-caption d-none d-md-block">
                    <p>'. $sauce->textedescription .'</p>
                    <p><a class="btn btn-lg btn-primary" href="Shop/">Achetez maintenant !</a></p>
                </div>
            </div>';
    if ($nbproduit == 2)
        $obj['result'] = $obj['result'] .
            '<div class="carousel-item active carousel-item-start">
                <svg class="bd-placeholder-img bd-placeholder-img-lg d-block w-100" width="800" height="400" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Third slide" preserveAspectRatio="xMidYMid slice" focusable="false">
                    <rect width="100%" height="100%" fill="#777">
                    </rect>
                    <text x="50%" y="50%" fill="#555" dy=".3em">' . $sauce->nom . '</text>
                </svg>
                <div class="carousel-caption d-none d-md-block">
                    <p>'. $sauce->textedescription .'</p>
                    <p><a class="btn btn-lg btn-primary" href="Shop/">Achetez maintenant !</a></p>
                </div>
            </div>';
    $nbproduit++;
}
echo json_encode($obj);

$req->closeCursor();
