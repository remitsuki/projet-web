<?php

session_start();
session_unset();
session_destroy();
header('Location: ../../Shop/index.php');
exit();
?>
