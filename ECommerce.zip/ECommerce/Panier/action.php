<?php
echo payementMethod;
header("Location: payement.php");
exit;
?>




