<?php
header("Location: ../../Panier/");
exit;
?>
