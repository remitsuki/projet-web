<?php

require '../config/accesbdd.php';

$chaine = "SELECT id FROM sauce ORDER BY id DESC";

$req = $access->prepare($chaine);

$req->execute();

$data = $req->fetchAll(PDO::FETCH_OBJ);

$id=-1;
$estDispo=false;
while ($estDispo==false)
{
    $id++;
    $estDispo=true;
    foreach ($data as $ident)
    {
        if ($ident->id==$id){
            $estDipo=false;
        }
    }
}




$nom =  $_GET['nom'];
$marque = $_GET['marque'];
$image =  $_GET['image'];
$quantite =  $_GET['quantite'];
$prix =  $_GET['prix'];
$niveau = $_GET['niveau'];
$description = $_GET['description'];
if ($nom=="" || strlen($nom)>64 || strlen($marque)>32 || $quantite<0 || $prix<0 || !is_numeric($prix) || !is_numeric($quantite) || !is_numeric($niveau)){
    

    echo '<html lang="fr">
    <head>
        <meta charset="utf-8">
        <title>Ajouter une sauce - Sauce Site</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    </head>
    <body class="text-center w-50 mx-auto mt-5 bg-dark">
        <style>p { color : white;}</style>
        <div class = "text-danger">
            Une erreur est survenue.
        </div>
        <form class="form-signin" action="ajouterBase.php" method="get">
            <p>Nom : </p><input  class="form-control" type="text" name="nom" value=""/>
            <p>Marque : </p><input  class="form-control" type="text" name="marque" value=""/>
            <p>Image (URL) : </p><input  class="form-control" type="text" name="image" value=""/>
            <p>Quantité : </p><input  class="form-control" type="text" name="quantite" value=""/>
            <p>Prix : </p><input  class="form-control" type="text" name="prix" value=""/>
            <p>Description : </p><input  class="form-control" type="textarea" name="description" value=""/>
            <p>Niveau : </p><input  class="form-control" type="text" name="niveau" value=""/>
            <div class="d-none"><p></p><input  class="form-control" type="text" id="id" name="id" value="" /></div>
            <input type="submit" value="Ajouter" />
        </form>
    </body>
    </html>';
}
else
{
    $chaine = "INSERT INTO sauce VALUES ($id, '$image', '$nom', $prix, $quantite, '$description', $niveau, '$marque')";

    $req = $access->prepare($chaine);

    $req->execute();

    header('location: index.php');
}


?>