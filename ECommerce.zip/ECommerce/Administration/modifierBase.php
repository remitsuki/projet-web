<?php

require '../config/accesbdd.php';


$nom =  $_GET['nom'];
$marque = $_GET['marque'];
$image =  $_GET['image'];
$quantite =  $_GET['quantite'];
$prix =  $_GET['prix'];
$id =  $_GET['id'];
$niveau = $_GET['niveau'];
$textedescription = $_GET['textedescription'];
if ($textedescription=="" || $nom=="" || strlen($nom)>64 || strlen($marque)>32 || $niveau<0 || $niveau>9 || $quantite<0 || $prix<0 || !is_numeric($prix) || !is_numeric($quantite) || !is_numeric($niveau)){
    $chaine = "SELECT * FROM sauce WHERE id = $id";


    $req = $access->prepare($chaine);

    $req->execute();

    $data = $req->fetchAll(PDO::FETCH_OBJ);

    $sauce = $data[0];



    echo '<!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="utf-8">
        <title>Modifier une sauce - Sauce Site</title>
        <link rel="stylesheet" href="style.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    </head>
    <body class="text-center w-50 mx-auto mt-5 bg-dark">
        <style>p { color : white;}</style>
        <div class = "text-danger">
            Une erreur est survenue.
        </div>
        <form action="modifierBase.php" method="get" class="form-signin">
            <p>Nom : </p><input class="form-control" type="text" name="nom" value="' . $sauce->nom . '"/>
            <p>Marque : </p><input class="form-control" type="text" name="marque" value="' . $sauce->marque . '"/>
            <p>Image : </p><img src=" ' . $sauce->image . ' " style="max-height: 500px;">
            <p>URL : </p><input class="form-control" type="text" name="image" value="' . $sauce->image . '"/>
            <p>Quantité : </p><input class="form-control" type="text" name="quantite" value="' . $sauce->quantite . '"/>
            <p>Prix : </p><input class="form-control" type="text" name="prix" value="' . $sauce->prix . '"/>
            <p>Description : </p><textarea type="text" name="textedescription" class ="form-control" >'. $sauce->textedescription .'</textarea>
            <p>Niveau : </p><input class="form-control" type="text" name="niveau" value="' . $sauce->niveau . '"/>
            <div class="masquer"><p></p><input class="form-control" type="text" id="id" name="id" value="'.$sauce->id.'" /></div>
            <input type="submit" value="modifier" />
        </form>
        <form action="supprimerSauce.php" method="get">
            <div class="masquer"><p></p><input type="text" id="id" name="id" value="'.$sauce->id.'" /></div>
            <input type="submit" value="supprimer" />
        </form>
    </body>
    </html>';
}
else
{
    $chaine = "UPDATE sauce SET nom='$nom', image='$image', quantite=$quantite, prix=$prix, marque='$marque', niveau=$niveau WHERE id=$id";
    
    $req = $access->prepare($chaine);

    $req->execute();

    $chaine = "UPDATE sauce SET textedescription='$textedescription' WHERE id=$id";
    
    $req = $access->prepare($chaine);

    $req->execute();

    header('location: index.php');
}


?>