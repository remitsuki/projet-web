<?php

require '../config/accesbdd.php';

$identifiant =  $_GET['id'];
$chaine = "SELECT * FROM sauce WHERE id = $identifiant";


$req = $access->prepare($chaine);

$req->execute();

$data = $req->fetchAll(PDO::FETCH_OBJ);

$sauce = $data[0];



echo '<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Modifier une sauce - Sauce Site</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
</head>
<body class="text-center w-50 mx-auto mt-5 bg-dark">
    <style>p { color : white;}</style>
    <form action="modifierBase.php" method="get" class="form-signin">
        <p>Nom : </p><input class="form-control" type="text" name="nom" value="' . $sauce->nom . '"/>
        <p>Marque : </p><input class="form-control" type="text" name="marque" value="' . $sauce->marque . '"/>
        <p>Image : </p><img src=" ' . $sauce->image . ' " style="max-height: 500px;">
        <p>URL : </p><input class="form-control" type="text" name="image" value="' . $sauce->image . '"/>
        <p>Quantité : </p><input class="form-control" type="text" name="quantite" value="' . $sauce->quantite . '"/>
        <p>Prix : </p><input class="form-control" type="text" name="prix" value="' . $sauce->prix . '"/>
        <p>Description : </p><textarea type="text" name="textedescription" class ="form-control" >'. $sauce->textedescription .'</textarea>
        <p>Niveau : </p><input class="form-control" type="text" name="niveau" value="' . $sauce->niveau . '"/>
        <div class="masquer"><p></p><input class="form-control" type="text" id="id" name="id" value="'.$sauce->id.'" /></div>
        <input type="submit" value="modifier" />
    </form>
    <form action="supprimerSauce.php" method="get">
        <div class="masquer"><p></p><input type="text" id="id" name="id" value="'.$sauce->id.'" /></div>
        <input type="submit" value="supprimer" />
    </form>
</body>
</html>';


?>
