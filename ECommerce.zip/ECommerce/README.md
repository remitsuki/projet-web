Projet réalisé par :
AMMARI Saad
BECUWE Abel
ORSOLIN Rémi
ROCH Félix
ROUSSEAU Sylvain

Le site Sauce Site nécessite la version 7.2.7 de PHP.
Il est nécessaire d'importer la base de données "saucesite" contenant les tables users et sauce.
Pour se connecter en mode administrateur, il faut placer le type à 1 lors de la création de l'utilisateur depuis myadmin. Un compte administrateur a déjà été créé :
	email : admin@admin.com
	mdp : password